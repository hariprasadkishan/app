/**
 * TrueEd Admin Verification Module
 * Handles: Teacher KYC review, approve/reject, user management, analytics
 */

const AdminVerify = {
  user: null,
  pendingTeachers: [],
  allTeachers: [],
  students: [],
  currentTab: "pending",
  selectedTeacher: null,

  async init() {
    if (!Auth.requireAuth()) return;
    if (!Auth.requireRole("admin")) return;

    await this.loadUser();
    await this.loadPendingTeachers();
    await this.loadStats();
    this.setupEventListeners();
    this.renderTeachers();
  },

  async loadUser() {
    const profile = localStorage.getItem("trueed_profile");
    this.user = profile ? JSON.parse(profile) : { name: "Admin" };
    const initials = this.user.name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

    const avatarEl = document.querySelector(".user-avatar");
    const nameEl = document.querySelector(".user-info p");
    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = this.user.name;
  },

  async loadPendingTeachers() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/admin/teachers/pending", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.pendingTeachers = await res.json();
      } else {
        this.pendingTeachers = this.getDemoPendingTeachers();
      }
    } catch (e) {
      this.pendingTeachers = this.getDemoPendingTeachers();
    }
  },

  getDemoPendingTeachers() {
    return [
      {
        id: "t1",
        name: "Ravi Kumar",
        email: "ravi.kumar@email.com",
        phone: "+91 98765 43210",
        subjects: ["Mathematics", "IIT JEE"],
        experience: "8 years",
        education: "IIT Bombay",
        location: "Indiranagar, Bangalore",
        mode: "both",
        hourlyRate: 500,
        bio: "Experienced mathematics teacher with 8+ years of teaching CBSE and IIT JEE students.",
        submittedAt: "2026-05-20T10:30:00Z",
        documents: {
          idProof: "https://example.com/id1.pdf",
          degree: "https://example.com/degree1.pdf",
          photo: "https://example.com/photo1.jpg",
        },
      },
      {
        id: "t2",
        name: "Sneha Patel",
        email: "sneha.patel@email.com",
        phone: "+91 98765 43211",
        subjects: ["Physics", "NEET"],
        experience: "5 years",
        education: "IISc Bangalore",
        location: "Online",
        mode: "online",
        hourlyRate: 600,
        bio: "Physics expert specializing in NEET preparation and conceptual learning.",
        submittedAt: "2026-05-21T14:15:00Z",
        documents: {
          idProof: "https://example.com/id2.pdf",
          degree: "https://example.com/degree2.pdf",
          photo: "https://example.com/photo2.jpg",
        },
      },
      {
        id: "t3",
        name: "Amit Mishra",
        email: "amit.mishra@email.com",
        phone: "+91 98765 43212",
        subjects: ["Chemistry", "JEE Main"],
        experience: "10 years",
        education: "BHU Varanasi",
        location: "Koramangala, Bangalore",
        mode: "offline",
        hourlyRate: 450,
        bio: "Chemistry master with expertise in organic, inorganic and physical chemistry.",
        submittedAt: "2026-05-22T09:00:00Z",
        documents: {
          idProof: "https://example.com/id3.pdf",
          degree: "https://example.com/degree3.pdf",
          photo: "https://example.com/photo3.jpg",
        },
      },
    ];
  },

  async loadStats() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/admin/stats", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        const stats = await res.json();
        this.renderAdminStats(stats);
      } else {
        this.renderAdminStats({
          totalTeachers: 156,
          pendingKYC: 12,
          totalStudents: 1240,
          totalSessions: 3420,
          totalRevenue: 856000,
        });
      }
    } catch (e) {
      this.renderAdminStats({
        totalTeachers: 156,
        pendingKYC: 12,
        totalStudents: 1240,
        totalSessions: 3420,
        totalRevenue: 856000,
      });
    }
  },

  renderAdminStats(stats) {
    const statsContainer = document.querySelector(".admin-stats");
    if (!statsContainer) return;

    statsContainer.innerHTML = `
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-chalkboard-teacher"></i></div>
        <div class="stat-value">${stats.totalTeachers}</div>
        <div class="stat-label">Total Teachers</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber"><i class="fas fa-clock"></i></div>
        <div class="stat-value">${stats.pendingKYC}</div>
        <div class="stat-label">Pending KYC</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-graduate"></i></div>
        <div class="stat-value">${stats.totalStudents}</div>
        <div class="stat-label">Total Students</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-calendar-check"></i></div>
        <div class="stat-value">${stats.totalSessions}</div>
        <div class="stat-label">Total Sessions</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:rgba(245,166,35,0.1);color:var(--amber);"><i class="fas fa-rupee-sign"></i></div>
        <div class="stat-value">₹${(stats.totalRevenue / 1000).toFixed(0)}k</div>
        <div class="stat-label">Total Revenue</div>
      </div>
    `;
  },

  renderTeachers() {
    const container = document.getElementById("teachers-list");
    if (!container) return;

    const teachers =
      this.currentTab === "pending" ? this.pendingTeachers : this.allTeachers;

    if (teachers.length === 0) {
      container.innerHTML = `
        <div style="text-align:center;padding:3rem;color:var(--muted);">
          <i class="fas fa-check-circle" style="font-size:3rem;margin-bottom:1rem;opacity:0.3;"></i>
          <p>No ${this.currentTab} teachers found.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = teachers
      .map(
        (t) => `
      <div class="teacher-review-card" data-id="${t.id}">
        <div class="teacher-review-header">
          <div class="teacher-review-avatar">${t.name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .toUpperCase()}</div>
          <div class="teacher-review-info">
            <h4>${t.name}</h4>
            <p>${t.education} • ${t.experience}</p>
            <span class="review-meta">
              <i class="fas fa-map-marker-alt"></i> ${t.location}
              <i class="fas fa-rupee-sign" style="margin-left:1rem;"></i> ${t.hourlyRate}/hr
              <i class="fas fa-clock" style="margin-left:1rem;"></i> ${new Date(t.submittedAt).toLocaleDateString()}
            </span>
          </div>
          <div class="review-actions">
            ${
              this.currentTab === "pending"
                ? `
              <button class="btn-sm btn-success" onclick="AdminVerify.approveTeacher('${t.id}')">
                <i class="fas fa-check"></i> Approve
              </button>
              <button class="btn-sm btn-danger" onclick="AdminVerify.rejectTeacher('${t.id}')">
                <i class="fas fa-times"></i> Reject
              </button>
            `
                : `
              <span class="status-badge status-approved">Approved</span>
            `
            }
            <button class="btn-sm btn-outline" onclick="AdminVerify.viewDetails('${t.id}')">
              <i class="fas fa-eye"></i> View
            </button>
          </div>
        </div>
        <div class="teacher-review-body">
          <p><strong>Subjects:</strong> ${t.subjects.join(", ")}</p>
          <p><strong>Bio:</strong> ${t.bio}</p>
          <div class="document-links">
            <a href="${t.documents.idProof}" target="_blank" class="doc-link"><i class="fas fa-id-card"></i> ID Proof</a>
            <a href="${t.documents.degree}" target="_blank" class="doc-link"><i class="fas fa-graduation-cap"></i> Degree</a>
            <a href="${t.documents.photo}" target="_blank" class="doc-link"><i class="fas fa-image"></i> Photo</a>
          </div>
        </div>
      </div>
    `,
      )
      .join("");
  },

  async approveTeacher(teacherId) {
    if (
      !confirm(
        "Approve this teacher? They will be able to start accepting bookings.",
      )
    )
      return;

    try {
      const token = localStorage.getItem("trueed_token");
      await fetch(`/api/admin/teachers/${teacherId}/approve`, {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
      });

      // Update Firestore
      await db
        .collection("teachers")
        .doc(teacherId)
        .update({
          kycStatus: "approved",
          approvedAt: firebase.firestore.FieldValue.serverTimestamp(),
          approvedBy: localStorage.getItem("trueed_uid"),
        });

      await db.collection("users").doc(teacherId).update({
        kycStatus: "approved",
      });

      // Remove from pending
      this.pendingTeachers = this.pendingTeachers.filter(
        (t) => t.id !== teacherId,
      );
      this.renderTeachers();
      alert("Teacher approved successfully!");
    } catch (e) {
      console.error("Approve error:", e);
      // Demo fallback
      this.pendingTeachers = this.pendingTeachers.filter(
        (t) => t.id !== teacherId,
      );
      this.renderTeachers();
      alert("Demo: Teacher approved!");
    }
  },

  async rejectTeacher(teacherId) {
    const reason = prompt("Please enter rejection reason (optional):");
    if (reason === null) return; // Cancelled

    try {
      const token = localStorage.getItem("trueed_token");
      await fetch(`/api/admin/teachers/${teacherId}/reject`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ reason }),
      });

      await db
        .collection("teachers")
        .doc(teacherId)
        .update({
          kycStatus: "rejected",
          rejectedAt: firebase.firestore.FieldValue.serverTimestamp(),
          rejectionReason: reason || "Not specified",
        });

      await db.collection("users").doc(teacherId).update({
        kycStatus: "rejected",
      });

      this.pendingTeachers = this.pendingTeachers.filter(
        (t) => t.id !== teacherId,
      );
      this.renderTeachers();
      alert("Teacher rejected. They will be notified to resubmit.");
    } catch (e) {
      this.pendingTeachers = this.pendingTeachers.filter(
        (t) => t.id !== teacherId,
      );
      this.renderTeachers();
      alert("Demo: Teacher rejected.");
    }
  },

  viewDetails(teacherId) {
    const teacher = this.pendingTeachers.find((t) => t.id === teacherId);
    if (!teacher) return;

    // Open modal or expand card
    const modal = document.getElementById("teacher-modal");
    if (modal) {
      modal.innerHTML = `
        <div class="modal-content">
          <div class="modal-header">
            <h2>${teacher.name}</h2>
            <button class="modal-close" onclick="AdminVerify.closeModal()">&times;</button>
          </div>
          <div class="modal-body">
            <div class="detail-row">
              <span>Email:</span> <strong>${teacher.email}</strong>
            </div>
            <div class="detail-row">
              <span>Phone:</span> <strong>${teacher.phone}</strong>
            </div>
            <div class="detail-row">
              <span>Education:</span> <strong>${teacher.education}</strong>
            </div>
            <div class="detail-row">
              <span>Experience:</span> <strong>${teacher.experience}</strong>
            </div>
            <div class="detail-row">
              <span>Subjects:</span> <strong>${teacher.subjects.join(", ")}</strong>
            </div>
            <div class="detail-row">
              <span>Hourly Rate:</span> <strong>₹${teacher.hourlyRate}</strong>
            </div>
            <div class="detail-row">
              <span>Location:</span> <strong>${teacher.location}</strong>
            </div>
            <div class="detail-row">
              <span>Mode:</span> <strong>${teacher.mode}</strong>
            </div>
            <div class="detail-row">
              <span>Bio:</span>
              <p>${teacher.bio}</p>
            </div>
            <div class="detail-row">
              <span>Documents:</span>
              <div class="document-links">
                <a href="${teacher.documents.idProof}" target="_blank"><i class="fas fa-id-card"></i> ID Proof</a>
                <a href="${teacher.documents.degree}" target="_blank"><i class="fas fa-graduation-cap"></i> Degree</a>
                <a href="${teacher.documents.photo}" target="_blank"><i class="fas fa-image"></i> Photo</a>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-sm btn-success" onclick="AdminVerify.approveTeacher('${teacher.id}');AdminVerify.closeModal();">
              <i class="fas fa-check"></i> Approve
            </button>
            <button class="btn-sm btn-danger" onclick="AdminVerify.rejectTeacher('${teacher.id}');AdminVerify.closeModal();">
              <i class="fas fa-times"></i> Reject
            </button>
          </div>
        </div>
      `;
      modal.classList.add("show");
    }
  },

  closeModal() {
    const modal = document.getElementById("teacher-modal");
    if (modal) modal.classList.remove("show");
  },

  switchTab(tab) {
    this.currentTab = tab;
    document
      .querySelectorAll(".tab-btn")
      .forEach((btn) => btn.classList.remove("active"));
    document.querySelector(`[data-tab="${tab}"]`)?.classList.add("active");
    this.renderTeachers();
  },

  setupEventListeners() {
    // Tab switching
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => this.switchTab(btn.dataset.tab));
    });

    // Search
    const searchInput = document.getElementById("admin-search");
    if (searchInput) {
      searchInput.addEventListener(
        "input",
        this.debounce((e) => {
          this.searchTeachers(e.target.value);
        }, 400),
      );
    }
  },

  debounce(fn, ms) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), ms);
    };
  },

  searchTeachers(query) {
    if (!query) {
      this.renderTeachers();
      return;
    }
    const q = query.toLowerCase();
    const teachers =
      this.currentTab === "pending" ? this.pendingTeachers : this.allTeachers;
    const filtered = teachers.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.email.toLowerCase().includes(q) ||
        t.subjects.some((s) => s.toLowerCase().includes(q)),
    );

    const container = document.getElementById("teachers-list");
    if (container) {
      container.innerHTML = filtered
        .map(
          (t) => `
        <div class="teacher-review-card" data-id="${t.id}">
          <div class="teacher-review-header">
            <div class="teacher-review-avatar">${t.name
              .split(" ")
              .map((n) => n[0])
              .join("")
              .toUpperCase()}</div>
            <div class="teacher-review-info">
              <h4>${t.name}</h4>
              <p>${t.education} • ${t.experience}</p>
            </div>
            <div class="review-actions">
              <button class="btn-sm btn-outline" onclick="AdminVerify.viewDetails('${t.id}')">View</button>
            </div>
          </div>
        </div>
      `,
        )
        .join("");
    }
  },

  toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("open");
    document.querySelector(".overlay").classList.toggle("show");
  },

  setActiveNav(el) {
    document
      .querySelectorAll(".nav-item")
      .forEach((i) => i.classList.remove("active"));
    el.classList.add("active");
    if (window.innerWidth <= 1024) this.toggleSidebar();
  },
};

// Global wrappers
window.toggleSidebar = () => AdminVerify.toggleSidebar();
window.setActive = (el) => AdminVerify.setActiveNav(el);
window.approveTeacher = (id) => AdminVerify.approveTeacher(id);
window.rejectTeacher = (id) => AdminVerify.rejectTeacher(id);
window.viewDetails = (id) => AdminVerify.viewDetails(id);
window.closeModal = () => AdminVerify.closeModal();
window.switchTab = (tab) => AdminVerify.switchTab(tab);

document.addEventListener("DOMContentLoaded", () => AdminVerify.init());
