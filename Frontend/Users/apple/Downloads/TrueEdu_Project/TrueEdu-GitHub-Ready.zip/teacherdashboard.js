// ─────────────────────────────────────────────
//  TrueEd — teacher-dashboard.js
// ─────────────────────────────────────────────

const TOKEN = localStorage.getItem("trueed_token");
let allBookings = [];
let currentTab = "upcoming";
let selectedDays = [];

document.addEventListener("DOMContentLoaded", () => {
  if (!Auth.requireRole("teacher")) return;
  fetchDashboard();
});

async function fetchDashboard() {
  try {
    const [bookRes, earnRes, availRes] = await Promise.all([
      fetch("/api/teachers/bookings", {
        headers: { Authorization: "Bearer " + TOKEN },
      }),
      fetch("/api/teachers/earnings", {
        headers: { Authorization: "Bearer " + TOKEN },
      }),
      fetch("/api/teachers/availability", {
        headers: { Authorization: "Bearer " + TOKEN },
      }),
    ]);

    const bookData = await bookRes.json();
    const earnData = await earnRes.json();
    const availData = await availRes.json();

    // Bookings
    allBookings = bookData.bookings || [];
    document.getElementById("earn-sessions").textContent = allBookings.filter(
      (b) => b.status === "completed",
    ).length;

    // Earnings
    if (earnData) {
      document.getElementById("earn-held").textContent =
        "₹" + (earnData.held || 0);
      document.getElementById("earn-released").textContent =
        "₹" + (earnData.released || 0);
      document.getElementById("earn-transferred").textContent =
        "₹" + (earnData.transferred || 0);
    }

    // Availability
    if (availData) {
      selectedDays = availData.days || [];
      document.querySelectorAll(".day-btn").forEach((btn) => {
        btn.classList.toggle(
          "active",
          selectedDays.includes(btn.textContent.trim()),
        );
      });
      if (availData.from)
        document.getElementById("time-from").value = availData.from;
      if (availData.to) document.getElementById("time-to").value = availData.to;

      // Toggle switch state
      const isAvailable = availData.isAvailable ?? true;
      document.getElementById("availability-switch").checked = isAvailable;
      updateAvailLabel(isAvailable);
    }

    // Greeting
    const phone = localStorage.getItem("trueed_phone") || "";
    document.getElementById("teacher-greeting").textContent =
      `Welcome back${phone ? ", " + phone : ""}!`;

    renderBookings(currentTab);
  } catch (err) {
    console.error(err);
  }
}

// ── Availability toggle ───────────────────────
async function toggleAvailability(isOn) {
  updateAvailLabel(isOn);
  try {
    await fetch("/api/teachers/availability/toggle", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + TOKEN,
      },
      body: JSON.stringify({ isAvailable: isOn }),
    });
  } catch (err) {
    console.error(err);
  }
}

function updateAvailLabel(isOn) {
  const label = document.getElementById("avail-label");
  const status = document.getElementById("avail-status");
  label.textContent = isOn ? "Online" : "Offline";
  status.textContent = isOn ? "Available" : "Unavailable";
  status.style.color = isOn ? "#16a34a" : "#94a3b8";
}

// ── Days selection ────────────────────────────
function toggleDay(btn, day) {
  btn.classList.toggle("active");
  if (selectedDays.includes(day)) {
    selectedDays = selectedDays.filter((d) => d !== day);
  } else {
    selectedDays.push(day);
  }
}

async function saveAvailability() {
  const from = document.getElementById("time-from").value;
  const to = document.getElementById("time-to").value;

  if (!selectedDays.length) {
    alert("Select at least one day.");
    return;
  }
  if (!from || !to) {
    alert("Set your available hours.");
    return;
  }

  try {
    const res = await fetch("/api/teachers/availability", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + TOKEN,
      },
      body: JSON.stringify({ days: selectedDays, from, to }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    alert("Availability saved!");
  } catch (err) {
    alert("Error: " + err.message);
  }
}

// ── Render bookings ───────────────────────────
function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll(".tab").forEach((t, i) => {
    t.classList.toggle("active", ["upcoming", "completed", "all"][i] === tab);
  });
  renderBookings(tab);
}

function renderBookings(tab) {
  let bookings = allBookings;
  if (tab === "upcoming")
    bookings = allBookings.filter((b) => b.status === "upcoming");
  if (tab === "completed")
    bookings = allBookings.filter((b) => b.status === "completed");

  const container = document.getElementById("bookings-container");

  if (!bookings.length) {
    container.innerHTML = `<div class="empty-state"><p>No ${tab === "all" ? "" : tab} bookings yet.</p></div>`;
    return;
  }

  container.innerHTML = bookings
    .map(
      (b) => `
    <div class="booking-card">
      <div class="booking-header">
        <div class="student-info">
          <div class="avatar-sm">${getInitials(b.studentName || "S")}</div>
          <div>
            <div class="student-name">${b.studentName || "Student"}</div>
            <div class="student-sub">${b.subject} &bull; Class ${b.studentClass || "—"}</div>
          </div>
        </div>
        <span class="status-badge status-${b.status}">${capitalize(b.status)}</span>
      </div>

      <div class="booking-meta">
        <div><div class="meta-label">Date</div><div class="meta-val">${formatDate(b.date)}</div></div>
        <div><div class="meta-label">Time</div><div class="meta-val">${b.time || "—"}</div></div>
        <div><div class="meta-label">Duration</div><div class="meta-val">${b.duration} hr</div></div>
        <div><div class="meta-label">Your Earning</div><div class="meta-val">&#8377;${b.teacherEarning || 0}</div></div>
        <div><div class="meta-label">Payout</div>
          <div class="meta-val">
            <span class="payout-status ${b.payoutReleased ? "payout-released" : "payout-held"}">
              ${b.payoutReleased ? "Released" : "Held (48hr)"}
            </span>
          </div>
        </div>
      </div>
    </div>`,
    )
    .join("");
}

// ── Helpers ───────────────────────────────────
function getInitials(name) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}
function formatDate(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : "";
}
