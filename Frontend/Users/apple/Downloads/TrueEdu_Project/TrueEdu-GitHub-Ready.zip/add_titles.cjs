const fs = require('fs');
const path = require('path');

const pages = [
  { file: 'LandingPage.jsx', title: 'TrueEdu — Find Your Perfect Tutor' },
  { file: 'LoginPage.jsx', title: 'Login — TrueEdu' },
  { file: 'StudentDashboard.jsx', title: 'Student Dashboard — TrueEdu' },
  { file: 'StudentDiscover.jsx', title: 'Discover Tutors — TrueEdu' },
  { file: 'StudentBookings.jsx', title: 'My Bookings — TrueEdu' },
  { file: 'StudentFavourites.jsx', title: 'Favourite Teachers — TrueEdu' },
  { file: 'StudentPayments.jsx', title: 'Payment History — TrueEdu' },
  { file: 'StudentSettings.jsx', title: 'Settings — TrueEdu' },
  { file: 'TeacherDashboard.jsx', title: 'Teacher Dashboard — TrueEdu' },
  { file: 'TeacherStudents.jsx', title: 'My Students — TrueEdu' },
  { file: 'TeacherEarnings.jsx', title: 'Earnings — TrueEdu' },
  { file: 'TeacherReviews.jsx', title: 'Reviews — TrueEdu' },
  { file: 'TeacherSettings.jsx', title: 'Settings — TrueEdu' },
  { file: 'TeacherKYC.jsx', title: 'KYC Verification — TrueEdu' },
  { file: 'AdminVerify.jsx', title: 'Admin Verification — TrueEdu' },
  { file: 'Safety.jsx', title: 'Safety — TrueEdu' },
  { file: 'AboutUs.jsx', title: 'About Us — TrueEdu' },
  { file: 'Community.jsx', title: 'Community — TrueEdu' },
  { file: 'Legal.jsx', title: 'Privacy & Terms — TrueEdu' },
  { file: 'TeacherEarningsInfo.jsx', title: 'Teacher Earnings — TrueEdu' },
  { file: 'TeacherVerification.jsx', title: 'Teacher Verification — TrueEdu' },
];

const dir = '/Users/apple/Downloads/TrueEd 2/src/pages';

pages.forEach(({ file, title }) => {
  const filePath = path.join(dir, file);
  if (!fs.existsSync(filePath)) return;
  let content = fs.readFileSync(filePath, 'utf8');

  // Skip if title already added
  if (content.includes('document.title =')) return;

  // Add useEffect to imports if not present
  if (!content.includes('useEffect')) {
    if (content.includes("from 'react'")) {
      content = content.replace(/import\s+{([^}]*)}\s+from\s+'react';/, (match, p1) => {
        return `import { ${p1.trim()}, useEffect } from 'react';`;
      });
    } else {
      content = `import { useEffect } from 'react';\n` + content;
    }
  }

  // Insert useEffect just after component declaration
  const componentMatch = content.match(/const\s+\w+\s*=\s*\([^)]*\)\s*=>\s*\{/);
  if (componentMatch) {
    const insertPos = componentMatch.index + componentMatch[0].length;
    content = content.slice(0, insertPos) + `\n  useEffect(() => { document.title = '${title}'; }, []);` + content.slice(insertPos);
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Updated ${file}`);
  }
});
