// TrueEd Firebase Configuration
// Replace with your actual Firebase project credentials

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "trueed-app.firebaseapp.com",
  projectId: "trueed-app",
  storageBucket: "trueed-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456",
  measurementId: "G-XXXXXXXXXX",
};

// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// Export for ES modules (if needed)
// export { auth, db, storage, firebase };
