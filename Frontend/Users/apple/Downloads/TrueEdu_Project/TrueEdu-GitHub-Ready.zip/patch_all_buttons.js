import fs from 'fs';
import path from 'path';

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else {
      if (file.endsWith('.jsx')) results.push(file);
    }
  });
  return results;
}

const files = walk('src');

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  let newContent = content;
  
  // A crude but effective way to find <button and check if it has onClick before >
  // We can match <button followed by anything until >
  newContent = newContent.replace(/<button([\s\S]*?)>/g, (match, p1) => {
    if (p1.includes('onClick') || p1.includes('type="submit"')) {
      return match;
    }
    // If it has no onClick and no type="submit", add onClick
    return `<button onClick={() => console.log('clicked')}${p1}>`;
  });
  
  if (newContent !== content) {
    fs.writeFileSync(file, newContent);
  }
}
