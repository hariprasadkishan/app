/**
 * TrueEd Authentication Module
 * Handles: Phone OTP → Profile → Email OTP → Registration
 */

const Auth = {
  // State
  confirmationResult: null,
  emailOtpCode: null,
  tempProfile: {},
  recaptchaVerifier: null,

  // ===================== UTILITIES =====================
  showAlert(stepId, message, type = "error") {
    const el = document.getElementById("alert-" + stepId);
    if (!el) return;
    el.textContent = message;
    el.className = `alert alert-${type} show`;
    setTimeout(() => el.classList.remove("show"), 5000);
  },

  setLoading(btnId, loading) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.disabled = loading;
    if (loading) {
      btn.dataset.originalText = btn.innerHTML;
      btn.innerHTML = 'Please wait <span class="spinner"></span>';
    } else {
      btn.innerHTML = btn.dataset.originalText || btn.innerHTML;
    }
  },

  showStep(step) {
    document
      .querySelectorAll(".login-card")
      .forEach((c) => c.classList.add("hidden"));
    const target = document.getElementById("step-" + step);
    if (target) target.classList.remove("hidden");
  },

  // ===================== OTP INPUT UX =====================
  moveOtp(el, index, type) {
    el.value = el.value.replace(/[^0-9]/g, "");
    const inputs = document.querySelectorAll(`#${type}-otp-inputs input`);
    if (el.value && index < inputs.length - 1) {
      inputs[index + 1].focus();
    }
  },

  moveOtpBack(e, index, type) {
    if (e.key === "Backspace" && !e.target.value && index > 0) {
      const inputs = document.querySelectorAll(`#${type}-otp-inputs input`);
      inputs[index - 1].focus();
    }
  },

  getOtpValue(type) {
    const inputs = document.querySelectorAll(`#${type}-otp-inputs input`);
    return Array.from(inputs)
      .map((i) => i.value)
      .join("");
  },

  clearOtpInputs(type) {
    document
      .querySelectorAll(`#${type}-otp-inputs input`)
      .forEach((i) => (i.value = ""));
    const first = document.querySelector(`#${type}-otp-inputs input`);
    if (first) first.focus();
  },

  // ===================== STEP 1: PHONE OTP =====================
  async sendPhoneOTP() {
    const phoneInput = document.getElementById("phone");
    let phone = phoneInput ? phoneInput.value.trim() : "";
    if (phone && !phone.startsWith("+")) phone = "+91" + phone;

    if (!phone || phone.length < 10) {
      this.showAlert("phone", "Please enter a valid phone number");
      return;
    }

    this.setLoading("btn-send-otp", true);

    try {
      // Clear existing verifier
      if (this.recaptchaVerifier) {
        this.recaptchaVerifier.clear();
      }

      this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
        "recaptcha-container",
        {
          size: "normal",
          callback: () => {
            console.log("Recaptcha verified");
          },
          "expired-callback": () => {
            this.showAlert("phone", "Recaptcha expired. Please try again.");
            this.setLoading("btn-send-otp", false);
          },
        },
      );

      this.confirmationResult = await auth.signInWithPhoneNumber(
        phone,
        this.recaptchaVerifier,
      );

      const displayPhone = document.getElementById("display-phone");
      if (displayPhone) displayPhone.textContent = phone;

      this.clearOtpInputs("phone");
      this.showStep("phone-otp");
      this.showAlert("phone-otp", "OTP sent successfully!", "success");
    } catch (error) {
      console.error("Phone OTP error:", error);
      this.showAlert("phone", error.message || "Failed to send OTP");
      if (this.recaptchaVerifier) {
        this.recaptchaVerifier.clear();
        this.recaptchaVerifier = null;
      }
    } finally {
      this.setLoading("btn-send-otp", false);
    }
  },

  async resendPhoneOTP() {
    this.setLoading("btn-resend-phone", true);
    try {
      // Re-init recaptcha and resend
      if (this.recaptchaVerifier) {
        this.recaptchaVerifier.clear();
      }
      let phone = document.getElementById("phone").value.trim();
      if (phone && !phone.startsWith("+")) phone = "+91" + phone;
      this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
        "recaptcha-container",
        { size: "invisible" },
      );
      this.confirmationResult = await auth.signInWithPhoneNumber(
        phone,
        this.recaptchaVerifier,
      );
      this.clearOtpInputs("phone");
      this.showAlert("phone-otp", "New OTP sent!", "success");
    } catch (error) {
      this.showAlert("phone-otp", error.message);
    } finally {
      this.setLoading("btn-resend-phone", false);
    }
  },

  // ===================== STEP 2: VERIFY PHONE =====================
  async verifyPhoneOTP() {
    const otp = this.getOtpValue("phone");
    if (otp.length !== 6) {
      this.showAlert("phone-otp", "Please enter the complete 6-digit code");
      return;
    }

    this.setLoading("btn-verify-phone", true);

    try {
      const result = await this.confirmationResult.confirm(otp);
      const token = await result.user.getIdToken();
      localStorage.setItem("trueed_token", token);
      localStorage.setItem("trueed_uid", result.user.uid);
      localStorage.setItem("trueed_phone", result.user.phoneNumber);

      // Check if user exists in backend
      const userExists = await this.checkUserExists(token);

      if (userExists) {
        localStorage.setItem("trueed_role", userExists.role);
        this.routeByRole(userExists.role);
      } else {
        this.showStep("register");
      }
    } catch (error) {
      console.error("Verify OTP error:", error);
      this.showAlert("phone-otp", "Invalid OTP. Please try again.");
    } finally {
      this.setLoading("btn-verify-phone", false);
    }
  },

  async checkUserExists(token) {
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Server error");
      return await res.json();
    } catch (e) {
      // Fallback: check Firestore
      const uid = localStorage.getItem("trueed_uid");
      if (!uid) return null;
      const doc = await db.collection("users").doc(uid).get();
      return doc.exists ? doc.data() : null;
    }
  },

  // ===================== STEP 3: PROFILE =====================
  selectRole(el, role) {
    document
      .querySelectorAll(".role-option")
      .forEach((o) => o.classList.remove("active"));
    el.classList.add("active");
    const input = document.getElementById("reg-role");
    if (input) input.value = role;
  },

  async submitProfile() {
    const name = document.getElementById("reg-name")?.value.trim();
    const email = document.getElementById("reg-email")?.value.trim();
    const city = document.getElementById("reg-city")?.value.trim();
    const area = document.getElementById("reg-area")?.value.trim();
    const role = document.getElementById("reg-role")?.value;

    if (!name) {
      this.showAlert("register", "Please enter your name");
      return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      this.showAlert("register", "Please enter a valid email address");
      return;
    }
    if (!city) {
      this.showAlert("register", "Please enter your city");
      return;
    }

    this.tempProfile = { name, email, city, area, role };
    this.setLoading("btn-register", true);

    try {
      // Send email OTP via backend
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/auth/send-email-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();
      if (data.success) {
        const displayEmail = document.getElementById("display-email");
        if (displayEmail) displayEmail.textContent = email;
        this.clearOtpInputs("email");
        this.showStep("email-otp");
        this.showAlert(
          "email-otp",
          "Verification code sent to your email!",
          "success",
        );
      } else {
        this.showAlert("register", data.message || "Failed to send email code");
      }
    } catch (error) {
      console.error("Email OTP error:", error);
      // DEMO FALLBACK
      const displayEmail = document.getElementById("display-email");
      if (displayEmail) displayEmail.textContent = email;
      this.clearOtpInputs("email");
      this.showStep("email-otp");
      this.showAlert("email-otp", "Demo mode: Use code 654321", "success");
    } finally {
      this.setLoading("btn-register", false);
    }
  },

  // ===================== STEP 4: EMAIL OTP =====================
  async resendEmailOTP() {
    this.setLoading("btn-resend-email", true);
    try {
      const token = localStorage.getItem("trueed_token");
      const email = this.tempProfile.email;
      await fetch("/api/auth/send-email-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ email }),
      });
      this.clearOtpInputs("email");
      this.showAlert("email-otp", "New code sent!", "success");
    } catch (error) {
      this.clearOtpInputs("email");
      this.showAlert("email-otp", "Demo: Use 654321", "success");
    } finally {
      this.setLoading("btn-resend-email", false);
    }
  },

  async verifyEmailOTP() {
    const otp = this.getOtpValue("email");
    if (otp.length !== 6) {
      this.showAlert("email-otp", "Please enter the complete 6-digit code");
      return;
    }

    this.setLoading("btn-verify-email", true);

    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/auth/verify-email-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({
          email: this.tempProfile.email,
          otp,
          profile: this.tempProfile,
        }),
      });

      const data = await res.json();
      if (data.success) {
        localStorage.setItem("trueed_role", this.tempProfile.role);
        localStorage.setItem(
          "trueed_profile",
          JSON.stringify(this.tempProfile),
        );
        this.showStep("success");
      } else {
        this.showAlert(
          "email-otp",
          data.message || "Invalid verification code",
        );
      }
    } catch (error) {
      console.error("Verify email error:", error);
      // DEMO FALLBACK
      if (otp === "654321") {
        const role = this.tempProfile.role || "student";
        localStorage.setItem("trueed_role", role);
        localStorage.setItem(
          "trueed_profile",
          JSON.stringify(this.tempProfile),
        );
        // uid already set hoga phone verify pe, but just in case:
        if (!localStorage.getItem("trueed_uid")) {
          localStorage.setItem("trueed_uid", "demo_uid_" + Date.now());
        }
         if (!localStorage.getItem("trueed_token")) {
           localStorage.setItem("trueed_token", "demo_token_" + Date.now());
         }
        this.showStep("success");
      } else {
        this.showAlert("email-otp", "Invalid code. Demo: 654321");
      }
    } finally {
      this.setLoading("btn-verify-email", false);
    }
  },

  // ===================== ROUTING =====================
  routeByRole(role) {
    const routes = {
      student: "student-discover.html",
      teacher: "teacher-dashboard.html",
      admin: "admin-verify.html",
    };
    window.location.href = routes[role] || "index.html";
  },

  goToDashboard() {
    const role = localStorage.getItem("trueed_role");
    const uid = localStorage.getItem("trueed_uid");

    if (!role || !uid) {
      this.showAlert("success", "Session error. Please login again.");
      setTimeout(() => (window.location.href = "login.html"), 1500);
      return;
    }

    setTimeout(() => this.routeByRole(role), 300);
  },

  // ===================== AUTH STATE =====================
  
    //  — token refresh on page reload
    async init() {
  await new Promise((resolve) => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      unsubscribe(); // ✅ ek baar fire hone ke baad listener band karo
      if (user) {
        const freshToken = await user.getIdToken(true);
        localStorage.setItem("trueed_token", freshToken);
        localStorage.setItem("trueed_uid", user.uid);
      }
      resolve();
    });
  });
    

    // Auto-focus OTP inputs
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (
          mutation.target.id === "step-phone-otp" &&
          !mutation.target.classList.contains("hidden")
        ) {
          setTimeout(
            () => document.querySelector("#phone-otp-inputs input")?.focus(),
            100,
          );
        }
        if (
          mutation.target.id === "step-email-otp" &&
          !mutation.target.classList.contains("hidden")
        ) {
          setTimeout(
            () => document.querySelector("#email-otp-inputs input")?.focus(),
            100,
          );
        }
      });
    });

    document.querySelectorAll(".login-card").forEach((card) => {
      observer.observe(card, { attributes: true, attributeFilter: ["class"] });
    });
  },

  // ===================== LOGOUT =====================
  logout() {
    auth.signOut().then(() => {
      localStorage.clear();
      window.location.href = "login.html";
    });
  },

  // ===================== GUARD =====================
  requireAuth() {
    const token = localStorage.getItem("trueed_token");
    const uid = localStorage.getItem("trueed_uid");
    const role = localStorage.getItem("trueed_role");
    if (!token || !uid || !role) {
      window.location.href = "login.html";
      return false;
    }
    return true;
  },

  requireRole(expectedRole) {
    if (!this.requireAuth()) return false;
    const role = localStorage.getItem("trueed_role");
    if (role !== expectedRole) {
      this.routeByRole(role);
      return false;
    }
    return true;
  },
};

// Global function wrappers for HTML onclick
defineGlobal("sendOTP", () => Auth.sendPhoneOTP());
defineGlobal("resendOTP", () => Auth.resendPhoneOTP());
defineGlobal("verifyOTP", () => Auth.verifyPhoneOTP());
defineGlobal("selectRole", (el, role) => Auth.selectRole(el, role));
defineGlobal("register", () => Auth.submitProfile());
defineGlobal("resendEmailOTP", () => Auth.resendEmailOTP());
defineGlobal("verifyEmailOTP", () => Auth.verifyEmailOTP());
defineGlobal("goToDashboard", () => Auth.goToDashboard());
defineGlobal("showStep", (step) => Auth.showStep(step));
defineGlobal("moveOtp", (el, idx, type) => Auth.moveOtp(el, idx, type));
defineGlobal("moveOtpBack", (e, idx, type) => Auth.moveOtpBack(e, idx, type));

function defineGlobal(name, fn) {
  if (typeof window !== "undefined") {
    window[name] = fn;
  }
}

// Initialize
document.addEventListener("DOMContentLoaded", () => Auth.init());
