import fs from 'fs';

const files = [
  'src/components/teacher/QuickActions.jsx',
  'src/pages/StudentFavourites.jsx',
  'src/pages/Community.jsx',
  'src/pages/Safety.jsx',
  'src/pages/TeacherApply.jsx',
  'src/pages/PublicTeacherProfile.jsx'
];

for (const file of files) {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    // Regex to match <button ...> but ignore those with onClick, type="submit", etc.
    // Or simpler: replace `<button className=` with `<button onClick={() => console.log('clicked')} className=`
    // But we have to be careful not to override existing onClicks.
    
    // We can do a string replace for specific buttons found manually or regex.
    content = content.replace(/<button(\s+[^>]*?)?>/g, (match, p1) => {
      if (p1 && (p1.includes('onClick') || p1.includes('type="submit"'))) {
        return match;
      }
      // Insert onClick
      if (p1) {
        return `<button onClick={() => console.log('clicked')}${p1}>`;
      }
      return `<button onClick={() => console.log('clicked')}>`;
    });
    fs.writeFileSync(file, content);
  }
}
