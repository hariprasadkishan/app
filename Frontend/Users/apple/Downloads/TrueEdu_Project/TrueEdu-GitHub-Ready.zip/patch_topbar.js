const fs = require('fs');
let content = fs.readFileSync('src/components/shared/Topbar.jsx', 'utf8');

// Replace topbar bell
let bellSearch = `<button className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-cream transition text-slate-500 hover:text-navy group" aria-label="View notifications">
          <Bell className="w-5 h-5 group-hover:animate-shake" />
          {notificationsCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error rounded-full border border-white" />
          )}
        </button>`;

let bellReplace = `
        <div className="relative">
          <button 
            className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-cream transition text-slate-500 hover:text-navy group" 
            aria-label="View notifications"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <Bell className="w-5 h-5 group-hover:animate-shake" />
            {notifications.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error rounded-full border border-white" />
            )}
          </button>
          
          {showNotifications && (
            <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-brand shadow-brand-xl border border-slate-100 overflow-hidden z-50 animate-slide-up-sm">
              <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
                <span className="font-bold text-navy">Notifications</span>
                {notifications.length > 0 && (
                  <span className="text-xs bg-error/10 text-error px-2 py-0.5 rounded-full font-bold">{notifications.length}</span>
                )}
              </div>
              <div className="max-h-64 overflow-y-auto">
                {notifications.length > 0 ? (
                  notifications.map(n => (
                    <div key={n.id} className="px-4 py-3 border-b border-slate-50 hover:bg-slate-50 transition flex flex-col gap-1">
                      <p className="text-sm text-navy">{n.text}</p>
                      <button onClick={() => setNotifications(notifications.filter(x => x.id !== n.id))} className="text-xs text-sky font-semibold self-start hover:underline">
                        Mark as read
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-6 text-center text-sm text-muted">
                    No new notifications
                  </div>
                )}
              </div>
            </div>
          )}
        </div>`;

content = content.replace(bellSearch, bellReplace);

// Add notifications state
let stateSearch = `const notificationsCount = 2; // Demo count`;
let stateReplace = `const [notifications, setNotifications] = useState([
    { id: 1, text: 'Your class with Kavita Verma starts in 30 mins' },
    { id: 2, text: 'New message from Arun Singh' }
  ]);
  const [showNotifications, setShowNotifications] = useState(false);`;

content = content.replace(stateSearch, stateReplace);

fs.writeFileSync('src/components/shared/Topbar.jsx', content);
