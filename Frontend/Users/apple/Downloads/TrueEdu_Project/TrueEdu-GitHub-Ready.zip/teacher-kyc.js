/**
 * TrueEd Teacher Dashboard Module
 * Handles: Bookings, earnings, schedule, profile, analytics
 */

const TeacherDashboard = {
  user: null,
  stats: {},
  bookings: [],
  earnings: [],
  schedule: [],

  async init() {
    if (!Auth.requireAuth()) return;
    if (!Auth.requireRole("teacher")) return;

    await this.loadUser();
    await this.checkKYCStatus();
    await this.loadStats();
    await this.loadBookings();
    await this.loadEarnings();
    await this.loadSchedule();
    this.renderWeeklyGoal();
    this.animateStats();
    this.setupEventListeners();
  },

  async loadUser() {
    try {
      const token = localStorage.getItem("trueed_token");
      const uid = localStorage.getItem("trueed_uid");

      // Try Firestore first
      const doc = await db.collection("teachers").doc(uid).get();
      if (doc.exists) {
        this.user = doc.data();
      } else {
        const res = await fetch("/api/teacher/profile", {
          headers: { Authorization: "Bearer " + token },
        });
        if (res.ok) this.user = await res.json();
      }
    } catch (e) {
      const profile = localStorage.getItem("trueed_profile");
      this.user = profile
        ? JSON.parse(profile)
        : { name: "Teacher", city: "Bangalore" };
    }
    this.renderUser();
  },

  renderUser() {
    const name = this.user?.name || "Teacher";
    const city = this.user?.location || this.user?.city || "";
    const initials = name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

    const avatarEl = document.querySelector(".user-avatar");
    const nameEl = document.querySelector(".user-info p");
    const locEl = document.querySelector(".user-info span");
    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = name;
    if (locEl) locEl.textContent = `Teacher • ${city}`;

    // Welcome
    const welcomeH1 = document.querySelector(".welcome-text h1");
    if (welcomeH1) welcomeH1.textContent = `Hello, ${name.split(" ")[0]}! 👋`;
  },

  async checkKYCStatus() {
    const kycStatus = this.user?.kycStatus || "pending";
    if (kycStatus === "pending") {
      const banner = document.getElementById("kyc-banner");
      if (banner) banner.classList.remove("hidden");
    } else if (kycStatus === "rejected") {
      const banner = document.getElementById("kyc-rejected-banner");
      if (banner) banner.classList.remove("hidden");
    }
  },

  async loadStats() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/teacher/stats", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.stats = await res.json();
      } else {
        this.stats = this.getDemoStats();
      }
    } catch (e) {
      this.stats = this.getDemoStats();
    }
    this.renderStats();
  },

  getDemoStats() {
    return {
      totalStudents: 24,
      studentsChange: "+3",
      totalSessions: 156,
      sessionsChange: "+12",
      earnings: "₹45,200",
      earningsChange: "+₹8,500",
      rating: 4.8,
      ratingChange: "+0.1",
      pendingRequests: 5,
    };
  },

  renderStats() {
    const statValues = document.querySelectorAll(".stat-value");
    const stats = [
      this.stats.totalStudents,
      this.stats.totalSessions,
      this.stats.earnings,
      this.stats.rating,
    ];
    statValues.forEach((el, i) => {
      if (stats[i] !== undefined) {
        el.dataset.final = stats[i];
        el.textContent = "0";
      }
    });
  },

  animateStats() {
    const stats = document.querySelectorAll(".stat-value");
    stats.forEach((stat, i) => {
      const final = stat.dataset.final || stat.textContent;
      stat.textContent = "0";
      setTimeout(
        () => {
          stat.style.transition = "all 0.5s ease-out";
          stat.textContent = final;
        },
        200 + i * 100,
      );
    });
  },

  async loadBookings() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/teacher/bookings", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.bookings = await res.json();
      } else {
        this.bookings = this.getDemoBookings();
      }
    } catch (e) {
      this.bookings = this.getDemoBookings();
    }
    this.renderBookings();
  },

  getDemoBookings() {
    return [
      {
        id: "b1",
        student: "Arjun Sharma",
        subject: "Mathematics — Trigonometry",
        date: "26 May",
        time: "4:00 PM",
        status: "confirmed",
        avatar: "AS",
        amount: 500,
      },
      {
        id: "b2",
        student: "Priya Nair",
        subject: "Mathematics — Calculus",
        date: "27 May",
        time: "10:00 AM",
        status: "confirmed",
        avatar: "PN",
        amount: 500,
      },
      {
        id: "b3",
        student: "Rahul Verma",
        subject: "Mathematics — Algebra",
        date: "28 May",
        time: "2:00 PM",
        status: "pending",
        avatar: "RV",
        amount: 500,
      },
      {
        id: "b4",
        student: "Sneha Gupta",
        subject: "Mathematics — Geometry",
        date: "29 May",
        time: "11:00 AM",
        status: "pending",
        avatar: "SG",
        amount: 500,
      },
      {
        id: "b5",
        student: "Karan Malhotra",
        subject: "IIT JEE — Coordinate Geometry",
        date: "30 May",
        time: "3:00 PM",
        status: "confirmed",
        avatar: "KM",
        amount: 600,
      },
    ];
  },

  renderBookings() {
    const container = document.querySelector(".bookings-list");
    if (!container) return;

    container.innerHTML = this.bookings
      .map(
        (b) => `
      <div class="booking-item">
        <div class="booking-avatar">${b.avatar}</div>
        <div class="booking-info">
          <h4>${b.student}</h4>
          <p>${b.subject}</p>
          <span><i class="fas fa-calendar"></i> ${b.date} • ${b.time}</span>
        </div>
        <div class="booking-actions">
          <span class="booking-status status-${b.status}">${b.status}</span>
          ${
            b.status === "pending"
              ? `
            <button class="btn-sm btn-success" onclick="TeacherDashboard.acceptBooking('${b.id}')">Accept</button>
            <button class="btn-sm btn-danger" onclick="TeacherDashboard.rejectBooking('${b.id}')">Decline</button>
          `
              : `
            <button class="btn-sm btn-outline" onclick="TeacherDashboard.viewBooking('${b.id}')">View</button>
          `
          }
        </div>
      </div>
    `,
      )
      .join("");
  },

  async acceptBooking(bookingId) {
    try {
      const token = localStorage.getItem("trueed_token");
      await fetch(`/api/teacher/bookings/${bookingId}/accept`, {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
      });
      alert("Booking accepted! Student will be notified.");
      await this.loadBookings();
    } catch (e) {
      alert("Demo: Booking accepted!");
      const booking = this.bookings.find((b) => b.id === bookingId);
      if (booking) booking.status = "confirmed";
      this.renderBookings();
    }
  },

  async rejectBooking(bookingId) {
    if (!confirm("Are you sure you want to decline this booking?")) return;
    try {
      const token = localStorage.getItem("trueed_token");
      await fetch(`/api/teacher/bookings/${bookingId}/reject`, {
        method: "POST",
        headers: { Authorization: "Bearer " + token },
      });
      await this.loadBookings();
    } catch (e) {
      alert("Demo: Booking declined.");
      this.bookings = this.bookings.filter((b) => b.id !== bookingId);
      this.renderBookings();
    }
  },

  viewBooking(bookingId) {
    window.location.href = `booking-detail.html?id=${bookingId}`;
  },

  async loadEarnings() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/teacher/earnings", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.earnings = await res.json();
      } else {
        this.earnings = this.getDemoEarnings();
      }
    } catch (e) {
      this.earnings = this.getDemoEarnings();
    }
    this.renderEarningsChart();
  },

  getDemoEarnings() {
    return [
      { month: "Jan", amount: 28000 },
      { month: "Feb", amount: 32000 },
      { month: "Mar", amount: 35000 },
      { month: "Apr", amount: 42000 },
      { month: "May", amount: 45200 },
    ];
  },

  renderEarningsChart() {
    const canvas = document.getElementById("earnings-chart");
    if (!canvas) return;

    // Simple CSS bar chart fallback
    const max = Math.max(...this.earnings.map((e) => e.amount));
    const chartContainer = canvas.parentElement;
    chartContainer.innerHTML = `
      <div style="display:flex;align-items:flex-end;gap:1rem;height:200px;padding:1rem 0;">
        ${this.earnings
          .map(
            (e) => `
          <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:0.5rem;">
            <div style="width:100%;background:linear-gradient(180deg,var(--amber),var(--sky));border-radius:8px 8px 0 0;transition:height 0.5s ease-out;height:0;" data-height="${((e.amount / max) * 100).toFixed(0)}%"></div>
            <span style="font-size:0.8rem;color:var(--muted);font-weight:600;">${e.month}</span>
            <span style="font-size:0.75rem;color:var(--navy);font-weight:700;">₹${(e.amount / 1000).toFixed(1)}k</span>
          </div>
        `,
          )
          .join("")}
      </div>
    `;

    // Animate bars
    setTimeout(() => {
      chartContainer.querySelectorAll("[data-height]").forEach((bar) => {
        bar.style.height = bar.dataset.height;
      });
    }, 300);
  },

  async loadSchedule() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/teacher/schedule", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.schedule = await res.json();
      } else {
        this.schedule = this.getDemoSchedule();
      }
    } catch (e) {
      this.schedule = this.getDemoSchedule();
    }
    this.renderSchedule();
  },

  getDemoSchedule() {
    return [
      {
        day: "Mon",
        slots: [
          { time: "10:00 AM", booked: true, student: "Arjun S." },
          { time: "2:00 PM", booked: false },
          { time: "4:00 PM", booked: true, student: "Priya N." },
        ],
      },
      {
        day: "Tue",
        slots: [
          { time: "10:00 AM", booked: false },
          { time: "2:00 PM", booked: true, student: "Rahul V." },
          { time: "4:00 PM", booked: false },
        ],
      },
      {
        day: "Wed",
        slots: [
          { time: "10:00 AM", booked: true, student: "Sneha G." },
          { time: "2:00 PM", booked: false },
          { time: "4:00 PM", booked: false },
        ],
      },
      {
        day: "Thu",
        slots: [
          { time: "10:00 AM", booked: false },
          { time: "2:00 PM", booked: false },
          { time: "4:00 PM", booked: true, student: "Karan M." },
        ],
      },
      {
        day: "Fri",
        slots: [
          { time: "10:00 AM", booked: true, student: "Arjun S." },
          { time: "2:00 PM", booked: true, student: "Priya N." },
          { time: "4:00 PM", booked: false },
        ],
      },
      {
        day: "Sat",
        slots: [
          { time: "10:00 AM", booked: false },
          { time: "2:00 PM", booked: false },
          { time: "4:00 PM", booked: false },
        ],
      },
      {
        day: "Sun",
        slots: [
          { time: "10:00 AM", booked: false },
          { time: "2:00 PM", booked: false },
          { time: "4:00 PM", booked: false },
        ],
      },
    ];
  },

  renderSchedule() {
    const container = document.querySelector(".schedule-grid");
    if (!container) return;

    container.innerHTML = this.schedule
      .map(
        (day) => `
      <div class="schedule-day">
        <div class="day-header">${day.day}</div>
        ${day.slots
          .map(
            (slot) => `
          <div class="time-slot ${slot.booked ? "booked" : "free"}" onclick="${slot.booked ? "" : `TeacherDashboard.addSlot('${day.day}', '${slot.time}')`}">
            <span class="slot-time">${slot.time}</span>
            ${slot.booked ? `<span class="slot-student"><i class="fas fa-user"></i> ${slot.student}</span>` : '<span class="slot-free">Available</span>'}
          </div>
        `,
          )
          .join("")}
      </div>
    `,
      )
      .join("");
  },

  addSlot(day, time) {
    // Open modal to add availability
    console.log("Add slot:", day, time);
  },

  renderWeeklyGoal() {
    const progressBar = document.querySelector(
      '.teacher-goal [style*="height:8px"] > div',
    );
    if (progressBar) {
      const width = progressBar.style.width;
      progressBar.style.width = "0%";
      setTimeout(() => {
        progressBar.style.transition = "width 1s ease-out";
        progressBar.style.width = width || "75%";
      }, 500);
    }
  },

  setupEventListeners() {
    // Search
    const searchInput = document.querySelector(".search-box input");
    if (searchInput) {
      searchInput.addEventListener(
        "input",
        this.debounce((e) => {
          this.searchStudents(e.target.value);
        }, 400),
      );
    }
  },

  debounce(fn, ms) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), ms);
    };
  },

  searchStudents(query) {
    if (!query) {
      this.renderBookings();
      return;
    }
    const filtered = this.bookings.filter(
      (b) =>
        b.student.toLowerCase().includes(query.toLowerCase()) ||
        b.subject.toLowerCase().includes(query.toLowerCase()),
    );
    const container = document.querySelector(".bookings-list");
    if (container) {
      container.innerHTML = filtered
        .map(
          (b) => `
        <div class="booking-item">
          <div class="booking-avatar">${b.avatar}</div>
          <div class="booking-info">
            <h4>${b.student}</h4>
            <p>${b.subject}</p>
            <span><i class="fas fa-calendar"></i> ${b.date} • ${b.time}</span>
          </div>
          <div class="booking-actions">
            <span class="booking-status status-${b.status}">${b.status}</span>
            <button class="btn-sm btn-outline" onclick="TeacherDashboard.viewBooking('${b.id}')">View</button>
          </div>
        </div>
      `,
        )
        .join("");
    }
  },

  toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("open");
    document.querySelector(".overlay").classList.toggle("show");
  },

  setActiveNav(el) {
    document
      .querySelectorAll(".nav-item")
      .forEach((i) => i.classList.remove("active"));
    el.classList.add("active");
    if (window.innerWidth <= 1024) this.toggleSidebar();
  },

  goToKYC() {
    window.location.href = "teacher-kyc.html";
  },
};

// Global wrappers
window.toggleSidebar = () => TeacherDashboard.toggleSidebar();
window.setActive = (el) => TeacherDashboard.setActiveNav(el);
window.acceptBooking = (id) => TeacherDashboard.acceptBooking(id);
window.rejectBooking = (id) => TeacherDashboard.rejectBooking(id);
window.viewBooking = (id) => TeacherDashboard.viewBooking(id);
window.goToKYC = () => TeacherDashboard.goToKYC();

document.addEventListener("DOMContentLoaded", () => TeacherDashboard.init());
