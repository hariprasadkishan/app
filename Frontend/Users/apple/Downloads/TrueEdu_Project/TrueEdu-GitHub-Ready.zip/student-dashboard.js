/**
 * TrueEd Student Dashboard Module
 * Handles: Stats, sessions, activity, tutor recommendations, weekly goals
 */

const StudentDashboard = {
  user: null,
  stats: {},
  sessions: [],
  tutors: [],

  async init() {
    if (!Auth.requireAuth()) return;
    if (!Auth.requireRole("student")) return;

    await this.loadUser();
    await this.loadStats();
    await this.loadUpcomingSessions();
    await this.loadRecommendedTutors();
    await this.loadActivity();
    this.renderWeeklyGoal();
    this.animateStats();
    this.setupEventListeners();
  },

  async loadUser() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/student/profile", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.user = await res.json();
      } else {
        // Fallback from localStorage
        const profile = localStorage.getItem("trueed_profile");
        this.user = profile
          ? JSON.parse(profile)
          : { name: "Arjun Sharma", city: "Bangalore" };
      }
    } catch (e) {
      const profile = localStorage.getItem("trueed_profile");
      this.user = profile
        ? JSON.parse(profile)
        : { name: "Arjun Sharma", city: "Bangalore" };
    }
    this.renderUser();
  },

  renderUser() {
    const name = this.user?.name || "Student";
    const city = this.user?.city || "";
    const initials = name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);

    // Update welcome text
    const welcomeH1 = document.querySelector(".welcome-text h1");
    if (welcomeH1)
      welcomeH1.textContent = `Welcome back, ${name.split(" ")[0]}! 👋`;

    // Update sidebar user
    const avatarEl = document.querySelector(".user-avatar");
    const nameEl = document.querySelector(".user-info p");
    const locEl = document.querySelector(".user-info span");
    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = name;
    if (locEl) locEl.textContent = `Student • ${city}`;
  },

  async loadStats() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/student/stats", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.stats = await res.json();
      } else {
        this.stats = this.getDemoStats();
      }
    } catch (e) {
      this.stats = this.getDemoStats();
    }
    this.renderStats();
  },

  getDemoStats() {
    return {
      sessionsCompleted: 12,
      sessionsChange: "+3",
      learningHours: "48h",
      hoursChange: "+8h",
      avgRating: "4.8",
      ratingChange: "+0.2",
      streak: 7,
      streakMsg: "Keep it going!",
    };
  },

  renderStats() {
    const statValues = document.querySelectorAll(".stat-value");
    const stats = [
      this.stats.sessionsCompleted,
      this.stats.learningHours,
      this.stats.avgRating,
      this.stats.streak,
    ];
    statValues.forEach((el, i) => {
      if (stats[i] !== undefined) {
        el.dataset.final = stats[i];
        el.textContent = "0";
      }
    });
  },

  animateStats() {
    const stats = document.querySelectorAll(".stat-value");
    stats.forEach((stat, i) => {
      const final = stat.dataset.final || stat.textContent;
      stat.textContent = "0";
      setTimeout(
        () => {
          stat.style.transition = "all 0.5s ease-out";
          stat.textContent = final;
        },
        200 + i * 100,
      );
    });
  },

  async loadUpcomingSessions() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/student/sessions/upcoming", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        this.sessions = await res.json();
      } else {
        this.sessions = this.getDemoSessions();
      }
    } catch (e) {
      this.sessions = this.getDemoSessions();
    }
    this.renderSessions();
  },

  getDemoSessions() {
    return [
      {
        day: "26",
        month: "May",
        subject: "Mathematics — Trigonometry",
        tutor: "Ravi Kumar",
        time: "4:00 PM",
        status: "confirmed",
        color: "var(--amber)",
      },
      {
        day: "28",
        month: "May",
        subject: "Chemistry — Organic Basics",
        tutor: "Amit Mishra",
        time: "2:00 PM",
        status: "confirmed",
        color: "var(--sky)",
      },
      {
        day: "30",
        month: "May",
        subject: "Physics — Electrostatics",
        tutor: "Sneha Patel",
        time: "10:00 AM",
        status: "pending",
        color: "var(--warning)",
      },
    ];
  },

  renderSessions() {
    const container = document.querySelector(".session-list");
    if (!container) return;
    container.innerHTML = this.sessions
      .map(
        (s) => `
      <div class="session-item">
        <div class="session-time">
          <div class="day">${s.day}</div>
          <div class="month">${s.month}</div>
        </div>
        <div class="session-divider" style="background:${s.color};"></div>
        <div class="session-info">
          <h4>${s.subject}</h4>
          <p><i class="fas fa-user" style="margin-right:0.3rem;"></i>${s.tutor} • ${s.time}</p>
        </div>
        <span class="session-status status-${s.status}">${s.status.charAt(0).toUpperCase() + s.status.slice(1)}</span>
      </div>
    `,
      )
      .join("");
  },

  async loadRecommendedTutors() {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/student/tutors/recommended", {
        headers: { Authorization: "Bearer " + token },
      });
      if (res.ok) {
        const data = await res.json();
        this.tutors = data.tutors || data;
      } else {
        this.tutors = this.getDemoTutors();
      }
    } catch (e) {
      this.tutors = this.getDemoTutors();
    }
    this.renderTutors();
  },

  getDemoTutors() {
    return [
      {
        name: "Ravi Kumar",
        subject: "Mathematics",
        exp: "8 yrs",
        rating: 4.9,
        reviews: 124,
        price: 500,
        tags: ["CBSE 10th", "IIT JEE", "Algebra"],
        initials: "RK",
        color: "linear-gradient(135deg, var(--sky), var(--navy))",
      },
      {
        name: "Sneha Patel",
        subject: "Physics",
        exp: "5 yrs",
        rating: 5.0,
        reviews: 89,
        price: 600,
        tags: ["NEET", "Mechanics", "Electrostatics"],
        initials: "SP",
        color: "linear-gradient(135deg,#ec4899,#8b5cf6)",
      },
      {
        name: "Amit Mishra",
        subject: "Chemistry",
        exp: "10 yrs",
        rating: 4.2,
        reviews: 56,
        price: 450,
        tags: ["Organic", "Inorganic", "JEE Main"],
        initials: "AM",
        color: "linear-gradient(135deg,#10b981,#059669)",
      },
      {
        name: "Priya Rao",
        subject: "English & Literature",
        exp: "6 yrs",
        rating: 4.7,
        reviews: 203,
        price: 400,
        tags: ["Grammar", "Writing", "Spoken"],
        initials: "PR",
        color: "linear-gradient(135deg,#f59e0b,#d97706)",
      },
    ];
  },

  renderTutors() {
  const container = document.querySelector(".tutors-grid");
    if (!container) return;
    container.innerHTML = this.tutors
      .map(
        (t) => `
      <div class="tutor-card" onclick="StudentDashboard.viewTutor('${t.id || t.name}')">
        <div class="tutor-header">
          <div class="tutor-avatar" style="background:${t.color || "var(--sky)"};">${t.initials}</div>
          <div class="tutor-meta">
            <h4>${t.name}</h4>
            <p>${t.subject} • ${t.exp} exp</p>
          </div>
        </div>
        <div class="tutor-rating">
          ${this.renderStars(t.rating)}
          <span style="color:var(--text);margin-left:0.3rem;font-weight:600;">${t.rating}</span>
          <span style="color:var(--muted);">(${t.reviews} reviews)</span>
        </div>
        <div class="tutor-tags">
          ${t.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
        </div>
        <div class="tutor-footer">
          <div class="price">₹${t.price} <span>/ hour</span></div>
          <button class="btn-sm" onclick="event.stopPropagation();StudentDashboard.bookTutor('${t.id || t.name}')">Book Now</button>
        </div>
      </div>
    `,
      )
      .join("");
  },

  renderStars(rating) {
    let html = "";
    for (let i = 1; i <= 5; i++) {
      if (i <= Math.floor(rating)) html += '<i class="fas fa-star"></i>';
      else if (i - 0.5 <= rating)
        html += '<i class="fas fa-star-half-alt"></i>';
      else html += '<i class="far fa-star"></i>';
    }
    return html;
  },

  async loadActivity() {
    // Activity is static in demo, can be fetched from API
  },

  renderWeeklyGoal() {
    const progressBar = document.querySelector(
      '.section-card:last-child [style*="height:8px"] > div',
    );
    if (progressBar) {
      const width = progressBar.style.width;
      progressBar.style.width = "0%";
      setTimeout(() => {
        progressBar.style.transition = "width 1s ease-out";
        progressBar.style.width = width || "60%";
      }, 500);
    }
  },

  setupEventListeners() {
    // Search
  const searchInput = document.querySelector(".search-box input, #search-topic");
    if (searchInput) {
      searchInput.addEventListener(
        "input",
        this.debounce((e) => {
          this.searchTutors(e.target.value);
        }, 400),
      );
    }

    // Book Session button
    const bookBtn = document.querySelector(
      ".topbar-actions .icon-btn:last-child",
    );
    if (bookBtn) {
      bookBtn.addEventListener("click", () => {
        window.location.href = "student-discover.html";
      });
    }
  },

  debounce(fn, ms) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), ms);
    };
  },

  async searchTutors(query) {
    if (!query || query.length < 2) return;
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch(
        `/api/tutors/search?q=${encodeURIComponent(query)}`,
        {
          headers: { Authorization: "Bearer " + token },
        },
      );
      if (res.ok) {
        const results = await res.json();
        // Could show search results dropdown
        console.log("Search results:", results);
      }
    } catch (e) {
      console.log("Search error:", e);
    }
  },

  viewTutor(tutorId) {
    window.location.href = `tutor-profile.html?id=${tutorId}`;
  },

  async bookTutor(tutorId) {
    try {
      const token = localStorage.getItem("trueed_token");
      const res = await fetch("/api/student/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ tutorId }),
      });
      if (res.ok) {
        alert("Booking request sent! The tutor will confirm shortly.");
      } else {
        alert("Failed to send booking. Please try again.");
      }
    } catch (e) {
      alert("Demo: Booking request simulated!");
    }
  },

  toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("open");
    document.querySelector(".overlay").classList.toggle("show");
  },

  setActiveNav(el) {
    document
      .querySelectorAll(".nav-item")
      .forEach((i) => i.classList.remove("active"));
    el.classList.add("active");
    if (window.innerWidth <= 1024) this.toggleSidebar();
  },
};

// Global wrappers
window.toggleSidebar = () => StudentDashboard.toggleSidebar();
window.setActive = (el) => StudentDashboard.setActiveNav(el);

document.addEventListener("DOMContentLoaded", () => StudentDashboard.init());
