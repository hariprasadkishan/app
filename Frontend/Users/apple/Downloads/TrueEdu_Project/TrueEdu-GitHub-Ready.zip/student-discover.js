/**
 * TrueEd Student Discover Module
 * Handles: Search, filters, sorting, pagination, tutor cards
 */

const StudentDiscover = {
  tutors: [],
  filteredTutors: [],
  currentPage: 1,
  perPage: 6,
  filters: {
    subjects: [],
    grades: [],
    minRating: 0,
    minPrice: 300,
    maxPrice: 1000,
    location: [],
    experience: []
  },
  sortBy: 'recommended',

  async init() {
    if (!Auth.requireAuth()) return;
    if (!Auth.requireRole('student')) return;

    await this.loadUser();
    await this.loadTutors();
    this.setupFilters();
    this.setupSearch();
    this.setupSort();
    this.setupPagination();
    this.renderTutors();
  },

  async loadUser() {
    const profile = localStorage.getItem('trueed_profile');
    const user = profile ? JSON.parse(profile) : { name: 'Arjun Sharma', city: 'Bangalore' };
    const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

    const avatarEl = document.querySelector('.user-avatar');
    const nameEl = document.querySelector('.user-info p');
    const locEl = document.querySelector('.user-info span');
    if (avatarEl) avatarEl.textContent = initials;
    if (nameEl) nameEl.textContent = user.name;
    if (locEl) locEl.textContent = `Student • ${user.city}`;
  },

  async loadTutors() {
    try {
      const token = localStorage.getItem('trueed_token');
      const res = await fetch('/api/tutors', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      if (res.ok) {
        const data = await res.json();
        this.tutors = data.tutors || data; // handle both wrapped and unwrapped
      } else {
        this.tutors = this.getDemoTutors();
      }
    } catch (e) {
      this.tutors = this.getDemoTutors();
    }
    this.filteredTutors = [...this.tutors];
  },

  getDemoTutors() {
    return [
      { id: 't1', name: 'Ravi Kumar', subject: 'Mathematics', exp: '8 years', expYears: 8, rating: 4.9, reviews: 124, price: 500, tags: ['CBSE 10th', 'IIT JEE', 'Algebra', 'Calculus', 'Trigonometry'], initials: 'RK', color: 'linear-gradient(135deg, var(--sky), var(--navy))', education: 'IIT Bombay', location: 'Indiranagar, BLR', mode: 'both', verified: true, featured: true, badge: 'Top Rated', promo: 'First session 20% off' },
      { id: 't2', name: 'Sneha Patel', subject: 'Physics', exp: '5 years', expYears: 5, rating: 5.0, reviews: 89, price: 600, tags: ['NEET', 'Mechanics', 'Electrostatics', 'Optics'], initials: 'SP', color: 'linear-gradient(135deg,#ec4899,#8b5cf6)', education: 'IISc Bangalore', location: 'Online', mode: 'online', verified: true, featured: false, badge: null, promo: 'Group sessions available' },
      { id: 't3', name: 'Amit Mishra', subject: 'Chemistry', exp: '10 years', expYears: 10, rating: 4.2, reviews: 56, price: 450, tags: ['Organic', 'Inorganic', 'JEE Main', 'Physical Chem'], initials: 'AM', color: 'linear-gradient(135deg,#10b981,#059669)', education: 'BHU Varanasi', location: 'Koramangala, BLR', mode: 'offline', verified: true, featured: false, badge: null, promo: '3-session package available' },
      { id: 't4', name: 'Priya Rao', subject: 'English & Literature', exp: '6 years', expYears: 6, rating: 4.7, reviews: 203, price: 400, tags: ['Grammar', 'Writing', 'Spoken', 'Literature', 'IELTS'], initials: 'PR', color: 'linear-gradient(135deg,#f59e0b,#d97706)', education: 'EFLU Hyderabad', location: 'Online', mode: 'online', verified: true, featured: true, badge: 'Quick Response', promo: 'Usually replies in 10 min' },
      { id: 't5', name: 'Vikram Singh', subject: 'Biology & Life Sciences', exp: '7 years', expYears: 7, rating: 4.8, reviews: 67, price: 550, tags: ['NEET', 'Zoology', 'Botany', 'Human Physiology'], initials: 'VS', color: 'linear-gradient(135deg,#6366f1,#4f46e5)', education: 'AIIMS Delhi', location: 'Jayanagar, BLR', mode: 'both', verified: true, featured: false, badge: null, promo: 'Includes study notes' },
      { id: 't6', name: 'Neha Gupta', subject: 'Computer Science', exp: '4 years', expYears: 4, rating: 4.3, reviews: 41, price: 700, tags: ['Python', 'Data Structures', 'Web Dev', 'AI/ML Basics'], initials: 'NG', color: 'linear-gradient(135deg,#06b6d4,#0891b2)', education: 'BITS Pilani', location: 'Online', mode: 'online', verified: true, featured: false, badge: null, promo: 'Live coding sessions' },
      { id: 't7', name: 'Rajesh Iyer', subject: 'Mathematics', exp: '12 years', expYears: 12, rating: 4.6, reviews: 178, price: 650, tags: ['CBSE 12th', 'IIT JEE', 'Calculus', 'Coordinate Geometry'], initials: 'RI', color: 'linear-gradient(135deg,#8b5cf6,#7c3aed)', education: 'IIT Madras', location: 'Whitefield, BLR', mode: 'both', verified: true, featured: false, badge: null, promo: 'Crash course available' },
      { id: 't8', name: 'Ananya Desai', subject: 'History & Civics', exp: '3 years', expYears: 3, rating: 4.5, reviews: 34, price: 350, tags: ['CBSE 10th', 'Indian History', 'World History', 'Political Science'], initials: 'AD', color: 'linear-gradient(135deg,#f472b6,#db2777)', education: 'JNU Delhi', location: 'HSR Layout, BLR', mode: 'offline', verified: true, featured: false, badge: null, promo: 'Notes & mind maps included' }
    ];
  },

  setupFilters() {
    // Subject checkboxes
    document.querySelectorAll('.filter-section:first-child .filter-option input').forEach(cb => {
      cb.addEventListener('change', () => this.applyFilters());
    });

    // Grade checkboxes
    document.querySelectorAll('.filter-section:nth-child(2) .filter-option input').forEach(cb => {
      cb.addEventListener('change', () => this.applyFilters());
    });

    // Rating rows
    document.querySelectorAll('.star-row').forEach((row, idx) => {
      row.addEventListener('click', () => {
        const ratings = [5, 4, 3];
        this.filters.minRating = ratings[idx];
        this.applyFilters();
      });
    });

    // Price range
    const minPrice = document.querySelector('.price-range input:first-child');
    const maxPrice = document.querySelector('.price-range input:last-child');
    if (minPrice && maxPrice) {
      [minPrice, maxPrice].forEach(input => {
        input.addEventListener('change', () => {
          this.filters.minPrice = parseInt(minPrice.value) || 0;
          this.filters.maxPrice = parseInt(maxPrice.value) || 99999;
          this.applyFilters();
        });
      });
    }

    // Location
    document.querySelectorAll('.filter-section:nth-child(4) .filter-option input').forEach(cb => {
      cb.addEventListener('change', () => this.applyFilters());
    });

    // Experience
    document.querySelectorAll('.filter-section:nth-child(5) .filter-option input').forEach(cb => {
      cb.addEventListener('change', () => this.applyFilters());
    });

    // Reset button
    const resetBtn = document.querySelector('.filters-panel .btn-outline');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => this.resetFilters());
    }
  },

  applyFilters() {
    this.filteredTutors = this.tutors.filter(tutor => {
      // Subject filter
      const checkedSubjects = Array.from(document.querySelectorAll('.filter-section:first-child .filter-option input:checked'))
        .map(cb => cb.parentElement.textContent.trim().split(' ')[0]);
      if (checkedSubjects.length > 0) {
        const tutorSubjects = tutor.tags.map(t => t.toLowerCase());
        const match = checkedSubjects.some(s => 
          tutor.subject.toLowerCase().includes(s.toLowerCase()) ||
          tutorSubjects.some(ts => ts.includes(s.toLowerCase()))
        );
        if (!match) return false;
      }

      // Price filter
      if (tutor.price < this.filters.minPrice || tutor.price > this.filters.maxPrice) return false;

      // Rating filter
      if (tutor.rating < this.filters.minRating) return false;

      return true;
    });

    this.currentPage = 1;
    this.sortTutors();
    this.renderTutors();
  },

  resetFilters() {
    document.querySelectorAll('.filters-panel input[type="checkbox"]').forEach(cb => cb.checked = false);
    document.querySelectorAll('.price-range input').forEach(input => input.value = '');
    this.filters = { subjects: [], grades: [], minRating: 0, minPrice: 0, maxPrice: 99999, location: [], experience: [] };
    this.filteredTutors = [...this.tutors];
    this.currentPage = 1;
    this.renderTutors();
  },

  setupSort() {
    const sortDropdown = document.querySelector('.sort-dropdown');
    if (sortDropdown) {
      sortDropdown.addEventListener('change', (e) => {
        this.sortBy = e.target.value.toLowerCase().replace(/sort by: /, '').replace(/[^a-z]/g, '');
        this.sortTutors();
        this.renderTutors();
      });
    }
  },

  sortTutors() {
    const sorts = {
      recommended: (a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || b.rating - a.rating,
      toprated: (a, b) => b.rating - a.rating,
      pricelowtohigh: (a, b) => a.price - b.price,
      pricehightolow: (a, b) => b.price - a.price,
      mostexperienced: (a, b) => b.expYears - a.expYears
    };
    const sortFn = sorts[this.sortBy] || sorts.recommended;
    this.filteredTutors.sort(sortFn);
  },

  setupSearch() {
    // Hero search
    const heroSearch = document.querySelector('.hero-search-bar input');
    const heroBtn = document.querySelector('.hero-search-bar button');
    if (heroSearch && heroBtn) {
      heroBtn.addEventListener('click', () => this.search(heroSearch.value));
      heroSearch.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') this.search(heroSearch.value);
      });
    }

    // Popular tags
    document.querySelectorAll('.p-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        if (heroSearch) heroSearch.value = tag.textContent;
        this.search(tag.textContent);
      });
    });

    // Topbar search
    const topbarSearch = document.querySelector('.search-box input');
    if (topbarSearch) {
      topbarSearch.addEventListener('input', this.debounce((e) => {
        if (e.target.value.length >= 2) this.search(e.target.value);
      }, 400));
    }
  },

  search(query) {
    if (!query) {
      this.filteredTutors = [...this.tutors];
    } else {
      const q = query.toLowerCase();
      this.filteredTutors = this.tutors.filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.subject.toLowerCase().includes(q) ||
        t.tags.some(tag => tag.toLowerCase().includes(q)) ||
        t.location.toLowerCase().includes(q)
      );
    }
    this.currentPage = 1;
    this.renderTutors();
  },

  setupPagination() {
    // Pagination buttons are rendered dynamically
  },

  renderPagination() {
    const totalPages = Math.ceil(this.filteredTutors.length / this.perPage);
    const container = document.querySelector('.pagination');
    if (!container) return;

    let html = `
      <button class="page-btn" ${this.currentPage === 1 ? 'disabled' : ''} onclick="StudentDiscover.goToPage(${this.currentPage - 1})">
        <i class="fas fa-chevron-left"></i>
      </button>
    `;

    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || (i >= this.currentPage - 1 && i <= this.currentPage + 1)) {
        html += `<button class="page-btn ${i === this.currentPage ? 'active' : ''}" onclick="StudentDiscover.goToPage(${i})">${i}</button>`;
      } else if (i === this.currentPage - 2 || i === this.currentPage + 2) {
        html += `<span style="color:var(--muted);padding:0 0.5rem;">...</span>`;
      }
    }

    html += `
      <button class="page-btn" ${this.currentPage === totalPages ? 'disabled' : ''} onclick="StudentDiscover.goToPage(${this.currentPage + 1})">
        <i class="fas fa-chevron-right"></i>
      </button>
    `;

    container.innerHTML = html;
  },

  goToPage(page) {
    const totalPages = Math.ceil(this.filteredTutors.length / this.perPage);
    if (page < 1 || page > totalPages) return;
    this.currentPage = page;
    this.renderTutors();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  renderTutors() {
    const container = document.querySelector('.tutors-grid');
    const countEl = document.querySelector('.results-count');
    if (!container) return;

    const start = (this.currentPage - 1) * this.perPage;
    const end = start + this.perPage;
    const pageTutors = this.filteredTutors.slice(start, end);

    if (countEl) {
      const total = this.filteredTutors.length;
      countEl.innerHTML = `Showing <strong>${start + 1}–${Math.min(end, total)}</strong> of <strong>${total}</strong> tutors`;
    }

    if (pageTutors.length === 0) {
      container.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--muted);">
          <i class="fas fa-search" style="font-size:3rem;margin-bottom:1rem;opacity:0.3;"></i>
          <p>No tutors found matching your criteria.</p>
          <button class="btn-outline" style="margin-top:1rem;" onclick="StudentDiscover.resetFilters()">Reset Filters</button>
        </div>
      `;
      this.renderPagination();
      return;
    }

    container.innerHTML = pageTutors.map(t => this.renderTutorCard(t)).join('');
    this.renderPagination();
  },

  renderTutorCard(t) {
    const featuredClass = t.featured ? 'featured' : '';
    const badgeHtml = t.badge ? `<div class="featured-badge" style="${t.badge === 'Quick Response' ? 'background:var(--sky);color:#fff;' : ''}"><i class="fas fa-${t.badge === 'Top Rated' ? 'crown' : 'bolt'}"></i> ${t.badge}</div>` : '';

    return `
      <div class="tutor-card ${featuredClass}" onclick="StudentDiscover.viewTutor('${t.id}')">
        ${badgeHtml}
        <div class="tutor-header">
          <div class="tutor-avatar" style="background:${t.color};">${t.initials}</div>
          <div class="tutor-info">
            <h3>${t.name}</h3>
            <div class="subject">${t.subject}</div>
            <div class="tutor-rating">
              ${this.renderStars(t.rating)}
              <span class="score">${t.rating}</span>
              <span class="reviews">(${t.reviews} reviews)</span>
            </div>
          </div>
        </div>
        <div class="tutor-details">
          <span class="detail-chip"><i class="fas fa-briefcase"></i> ${t.exp}</span>
          <span class="detail-chip"><i class="fas fa-graduation-cap"></i> ${t.education}</span>
          <span class="detail-chip"><i class="fas fa-${t.mode === 'online' ? 'video' : 'map-marker-alt'}"></i> ${t.location}</span>
          <span class="detail-chip"><i class="fas fa-check-circle"></i> Verified</span>
        </div>
        <div class="tutor-tags">
          ${t.tags.map((tag, i) => {
            const classes = ['tag'];
            if (i === 2) classes.push('amber');
            if (i === 3) classes.push('green');
            return `<span class="${classes.join(' ')}">${tag}</span>`;
          }).join('')}
        </div>
        <div class="tutor-footer">
          <div class="price-block">
            <div class="price">₹${t.price} <span>/ hour</span></div>
            <div class="price-note"><i class="fas fa-${this.getPromoIcon(t.promo)}" style="margin-right:0.2rem;"></i>${t.promo}</div>
          </div>
          <div style="display:flex;gap:0.5rem;">
            <button class="btn-outline" onclick="event.stopPropagation();StudentDiscover.saveTutor('${t.id}')">Save</button>
            <button class="btn-primary" onclick="event.stopPropagation();StudentDiscover.bookTutor('${t.id}')">Book Now</button>
          </div>
        </div>
      </div>
    `;
  },

  renderStars(rating) {
    let html = '';
    for (let i = 1; i <= 5; i++) {
      if (i <= Math.floor(rating)) html += '<i class="fas fa-star"></i>';
      else if (i - 0.5 <= rating) html += '<i class="fas fa-star-half-alt"></i>';
      else html += '<i class="far fa-star"></i>';
    }
    return html;
  },

  getPromoIcon(promo) {
    if (promo.includes('off')) return 'tag';
    if (promo.includes('Group')) return 'users';
    if (promo.includes('package')) return 'gift';
    if (promo.includes('replies')) return 'clock';
    if (promo.includes('notes')) return 'clipboard-list';
    if (promo.includes('coding')) return 'laptop-code';
    if (promo.includes('Crash')) return 'rocket';
    if (promo.includes('mind')) return 'brain';
    return 'info-circle';
  },

  viewTutor(tutorId) {
    window.location.href = `tutor-profile.html?id=${tutorId}`;
  },

  async saveTutor(tutorId) {
    try {
      const token = localStorage.getItem('trueed_token');
      await fetch('/api/student/saved-tutors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ tutorId })
      });
      alert('Tutor saved to your list!');
    } catch (e) {
      alert('Demo: Tutor saved!');
    }
  },

  async bookTutor(tutorId) {
    try {
      const token = localStorage.getItem('trueed_token');
      const res = await fetch('/api/student/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify({ tutorId })
      });
      if (res.ok) {
        alert('Booking request sent! The tutor will confirm shortly.');
      } else {
        alert('Failed to send booking. Please try again.');
      }
    } catch (e) {
      alert('Demo: Booking request simulated!');
    }
  },

  debounce(fn, ms) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn(...args), ms);
    };
  },

  toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.querySelector('.overlay').classList.toggle('show');
  },

  toggleFilters() {
    document.getElementById('filters-panel').classList.toggle('show');
  }
};

// Global wrappers
window.toggleSidebar = () => StudentDiscover.toggleSidebar();
window.toggleFilters = () => StudentDiscover.toggleFilters();

document.addEventListener('DOMContentLoaded', () => StudentDiscover.init());